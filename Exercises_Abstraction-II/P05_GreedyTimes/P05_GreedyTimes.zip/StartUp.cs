﻿namespace P05_GreedyTimes
{

    public class StartUp
    {
        static void Main(string[] args)
        {
            Starter starter = new Starter();
            starter.Run();
            

            
        }
    }
}