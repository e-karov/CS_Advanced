﻿namespace P05_GreedyTimes
{
    using System;
    using System.Collections.Generic;


    public class Starter
    {
        public void Run()
        {
            long bagCapacity = long.Parse(Console.ReadLine());
            string[] safe = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            Bag bag = new Bag(bagCapacity);
            //bag.Items = new Dictionary<string, Dictionary<string, long>>();
            ItemCollector itemCollector = new ItemCollector();
            itemCollector.CollectItems(bag, safe);
            bag.PrintBagContent();
        }
    }
}
